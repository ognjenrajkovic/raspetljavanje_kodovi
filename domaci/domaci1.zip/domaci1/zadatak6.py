budzet = int(input())
broj_dana = int(input())
troskovi = 100

if troskovi * broj_dana <= budzet:
    print("Da")
else:
    print("Ne")