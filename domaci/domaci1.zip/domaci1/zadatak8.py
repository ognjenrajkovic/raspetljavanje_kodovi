V = int(input())
x = int(input())
y = int(input())

broj_sati = V // (x + y)

print(broj_sati)